import AboutPresenter from './about-presenter.js';

// Komponen halaman About untuk Story Hub
class AboutPage {
  #presenter = null;
  #aboutContainer = null;

  // Merender tampilan awal halaman About
  async render() {
    return `
            <a href="#main-content" class="skip-link">Skip to Content</a>
            <section class="about-page">
                <h1>About Story Hub</h1>
                <div id="main-content">
                    <div id="about-container">
                        <p>Memuat informasi tentang Story Hub...</p>
                    </div>
                </div>
            </section>
        `;
  }

  // Menjalankan logic setelah elemen dirender ke DOM
  async afterRender() {
        this.#aboutContainer = document.getElementById('about-container');
        this.#presenter = new AboutPresenter({ view: this });
        this.#presenter.loadAboutInfo();

        // Skip to Content
        const mainContent = document.querySelector('#main-content');
        const skipLink = document.querySelector('.skip-link');
        if (skipLink && mainContent) {
          skipLink.addEventListener('click', function (event) {
            event.preventDefault();
            skipLink.blur();
            mainContent.setAttribute('tabindex', '-1'); 
            mainContent.focus();
            mainContent.scrollIntoView();
          });
        }
    }

  // Menampilkan informasi tentang aplikasi
    showAboutInfo(description) {
        this.#aboutContainer.innerHTML = `<p>${description}</p>`;
    }

  // Menampilkan loading saat data about dimuat
    showLoading() {
        this.#aboutContainer.innerHTML = `<p>Memuat informasi...</p>`;
    }

  // Menampilkan pesan error jika gagal memuat data about
    showError(message) {
        this.#aboutContainer.innerHTML = `<p class="error-message">Terjadi kesalahan: ${message}</p>`;
    }
}

export default AboutPage;
