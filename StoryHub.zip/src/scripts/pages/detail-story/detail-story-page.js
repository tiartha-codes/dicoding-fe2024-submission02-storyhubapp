import DetailStoryPresenter from './detail-story-presenter.js';
import * as StoryHubAPI from '../../data/api.js';
import { getAccessToken } from '../../utils/util-auth.js';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { MAP_API_KEY } from '../../config';

class DetailStoryPage {
    #presenter = null;
    #storyDetailContainer = null;
    #mapContainer = null;
    #map = null;

    // Merender tampilan halaman detail story
    async render() {
        return `
            <a href="#main-content" class="skip-link">Skip to Content</a>
            <section class="detail-story-page">
                <h1>Story</h1>
                <div id="map-container" class="map-container"></div>
                <div id="main-content">
                    <div id="story-detail-container">
                        <p>Memuat detail Story...</p>
                    </div>
                </div>
                <button id="back-to-home" class="btn secondary">Kembali ke Beranda</button>
            </section>
        `;
    }

    // Dipanggil setelah elemen halaman dirender ke DOM dan inisialisasi presenter
    async afterRender() {
        this.#storyDetailContainer = document.getElementById('story-detail-container');
        this.#mapContainer = document.getElementById('map-container');
        const storyId = window.location.hash.split('/').pop();

        this.#presenter = new DetailStoryPresenter({
            view: this,
            model: StoryHubAPI,
            authModel: { getAccessToken },
        });

        await this.#presenter.loadStoryDetail(storyId);

        const backButton = document.getElementById('back-to-home');
        backButton.addEventListener('click', () => {
            window.location.hash = '/';
        });

        // Skip to Content
        const mainContent = document.querySelector('#main-content');
        const skipLink = document.querySelector('.skip-link');
        if (skipLink && mainContent) {
            skipLink.addEventListener('click', function (event) {
                event.preventDefault();
                skipLink.blur();
                mainContent.setAttribute('tabindex', '-1');
                mainContent.focus();
                mainContent.scrollIntoView();
            });
        }
    }

    // Menampilkan detail story ke dalam kontainer dan memanggil render peta
    showStoryDetail(story) {
        if (!story) {
            this.#storyDetailContainer.innerHTML = '<p class="error-message">Story tidak ditemukan.</p>';
            if (this.#map) {
                this.#map.remove();
                this.#map = null;
            }
            return;
        }

        this.#storyDetailContainer.innerHTML = `
            <div class="story-detail">
                <h1>Story ${story.name}</h1>
                <img src="${story.photoUrl}" alt="${story.description}">
                <div class="story-info">
                    <p class="story-date">Dibuat pada: ${new Date(story.createdAt).toLocaleString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit' })}</p>
                    <p class="story-description">${story.description}</p>
                    ${story.lat !== null && story.lon !== null ? `
                        <div class="story-location-group">
                            <span class="story-location-label">Latitude</span>
                            <span class="story-location-value">${story.lat}</span><br>
                            <span class="story-location-label">Longitude</span>
                            <span class="story-location-value">${story.lon}</span>
                        </div>
                    ` : ''}
                </div>
            </div>
        `;
        this.#renderMap(story);
    }

    // Merender peta dan marker lokasi story jika ada koordinat
    #renderMap(story) {
        if (!this.#mapContainer || story.lat === null || story.lon === null) return;

        // Definisikan custom icon sekali saja
        const customIcon = L.icon({
            iconUrl: 'https://leafletjs.com/examples/custom-icons/leaf-green.png',
            iconSize: [38, 95],
            iconAnchor: [22, 94],
            popupAnchor: [-2, -76],
        });

        if (!this.#map) {
            this.#map = L.map(this.#mapContainer).setView([story.lat, story.lon], 12);
            L.tileLayer(`https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png`, {
                attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            }).addTo(this.#map);
        } else {
            this.#map.setView([story.lat, story.lon], 12);
            this.#map.eachLayer(layer => {
                if (layer instanceof L.Marker) {
                    this.#map.removeLayer(layer);
                }
            });
        }

        L.marker([story.lat, story.lon], { icon: customIcon }).addTo(this.#map)
            .bindPopup(`<b>${story.name}</b><br>${story.description}`)
            .openPopup();
    }

    // Menampilkan loading indicator pada detail story dan peta
    showLoading() {
        this.#storyDetailContainer.innerHTML = '<p>Memuat detail Story...</p>';
        if (this.#mapContainer) this.#mapContainer.innerHTML = '<p>Memuat peta...</p>';
    }

    // Menampilkan pesan error pada detail story dan peta
    showError(message) {
        this.#storyDetailContainer.innerHTML = `<p class="error-message">Terjadi kesalahan: ${message}</p>`;
        if (this.#mapContainer) this.#mapContainer.innerHTML = `<p class="error-message">Terjadi kesalahan memuat peta.</p>`;
    }
}

export default DetailStoryPage;