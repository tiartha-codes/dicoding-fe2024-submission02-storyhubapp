// Presenter untuk mengelola logika detail story pada halaman detail
class DetailStoryPresenter {
    #view;
    #model;
    #authModel;

    // Konstruktor untuk inisialisasi presenter dengan view, model API, dan model autentikasi
    constructor({ view, model, authModel }) {
        this.#view = view;
        this.#model = model;
        this.#authModel = authModel;
    }

    // Fungsi utama untuk memuat detail story berdasarkan storyId
    // Memanggil API, cek token, dan mengatur feedback ke view
    async loadStoryDetail(storyId) {
        this.#view.showLoading();
        try {
            const token = this.#authModel.getAccessToken();
            if (!token) {
                this.#view.showError('Anda belum login.');
                return;
            }

            const response = await this.#model.getStoryDetail(storyId);
            console.log('DetailStoryPresenter: Respons dari getStoryDetail:', response);

            if (!response.error) {
                this.#view.showStoryDetail(response.story);
            } else {
                this.#view.showError(response.message || 'Gagal memuat detail Story.');
            }
        } catch (error) {
            console.error('DetailStoryPresenter: Terjadi kesalahan saat memuat detail Story:', error);
            this.#view.showError('Terjadi kesalahan saat memuat detail Story.');
        }
    }
}

export default DetailStoryPresenter;