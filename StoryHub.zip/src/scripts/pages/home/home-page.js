import HomePresenter from './home-presenter.js';
import * as StoryHubAPI from '../../data/api.js';
import { getAccessToken } from '../../utils/util-auth.js';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { MAP_API_KEY } from '../../config';

class HomePage {
    #presenter = null;
    #storyListContainer = null;
    #mapContainer = null;
    #map = null;

    // Merender tampilan halaman utama (home)
    async render() {
        return `
        <a href="#main-content" class="skip-link">Skip to Content</a>
        <section class="home-page">
            <div id="map-container" class="map-container"></div>
            <h1>Story Terbaru</h1>
            <div id="story-list-container" class="story-list">
                <p>Memuat story terbaru...</p>
            </div>
        </section>
    `;
    }

    // Dipanggil setelah elemen halaman dirender ke DOM dan inisialisasi presenter
    async afterRender() {
        this.#storyListContainer = document.getElementById('story-list-container');
        this.#mapContainer = document.getElementById('map-container');
        this.#presenter = new HomePresenter({
            view: this,
            model: StoryHubAPI,
            authModel: { getAccessToken },
        });

        // Skip to Content
        const mainContent = document.querySelector('#story-list-container');
        const skipLink = document.querySelector('.skip-link');
        if (skipLink && mainContent) {
            skipLink.addEventListener('click', function (event) {
                event.preventDefault();
                skipLink.blur();
                mainContent.setAttribute('tabindex', '-1');
                mainContent.focus();
                mainContent.scrollIntoView();
            });
        }   

        await this.#presenter.loadStories();
    }

    // Menampilkan daftar story ke dalam kontainer dan memanggil render peta
    showStories(stories) {
        if (!stories || stories.length === 0) {
            this.#storyListContainer.innerHTML = '<p>Belum ada story terbaru.</p>';
            // Hapus peta jika tidak ada story
            if (this.#map) {
                this.#map.remove();
                this.#map = null;
            }
            return;
        }

        this.#storyListContainer.innerHTML = '';
        this.#renderMap(stories); 

        // Tambahkan tabindex berurutan pada setiap story item
        stories.forEach((story, idx) => {
            const storyItem = document.createElement('div');
            storyItem.classList.add('story-item');
            storyItem.setAttribute('tabindex', idx + 1); // tabindex mulai dari 1, urut dari terbaru ke lama
            storyItem.innerHTML = `
                <img src="${story.photoUrl}" alt="${story.description}">
                <div class="story-info">
                    <h3>${story.name}</h3>
                    <p class="story-description">${story.description}</p>
                    <p class="story-date">${new Date(story.createdAt).toLocaleDateString()}</p>
                </div>
            `;
            storyItem.addEventListener('click', () => {
                window.location.hash = `/detail/${story.id}`;
            });
            storyItem.style.cursor = 'pointer';
            this.#storyListContainer.appendChild(storyItem);
        });
    }

    // Merender peta dan marker lokasi story jika ada koordinat
    #renderMap(stories) {
        if (!this.#mapContainer) return;

        // Definisikan custom icon sekali saja
        const customIcon = L.icon({
            iconUrl: 'https://leafletjs.com/examples/custom-icons/leaf-green.png',
            iconSize: [38, 95],
            iconAnchor: [22, 94],
            popupAnchor: [-2, -76],
        });

        if (!this.#map) {
            // Set initial view ke Indonesia
            this.#map = L.map(this.#mapContainer).setView([-2.5489, 118.0149], 5);
            L.tileLayer(`https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png`, {
                attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            }).addTo(this.#map);
        } else {
            this.#map.eachLayer(layer => {
                // Hapus marker lama
                if (layer instanceof L.Marker) {
                    this.#map.removeLayer(layer);
                }
            });
        }

        stories.forEach(story => {
            if (story.lat !== null && story.lon !== null) {
                // Gunakan custom icon untuk marker
                const marker = L.marker([story.lat, story.lon], { icon: customIcon }).addTo(this.#map);
                marker.bindPopup(`<b>${story.name}</b><br>${story.description}`);
            }
        });
    }

    // Menampilkan loading indicator pada daftar story dan peta
    showLoadingStories() {
        this.#storyListContainer.innerHTML = '<p>Memuat Story terbaru...</p>';
        if (this.#mapContainer) this.#mapContainer.innerHTML = '<p>Memuat peta...</p>';
    }

    // Menampilkan pesan error pada daftar story dan peta
    showErrorStories(message) {
        this.#storyListContainer.innerHTML = `<p class="error-message">Terjadi kesalahan memuat Story: ${message}</p>`;
        if (this.#mapContainer) this.#mapContainer.innerHTML = `<p class="error-message">Terjadi kesalahan memuat peta.</p>`;
    }
}

export default HomePage;