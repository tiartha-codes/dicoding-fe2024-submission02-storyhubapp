// Presenter untuk mengelola logika registrasi pada halaman register
export default class RegisterPresenter {
    #view;
    #model;

    // Konstruktor untuk inisialisasi presenter dengan view dan model API
    constructor({ view, model }) {
        console.log('Model instance in RegisterPresenter:', model); // Debugging
        this.#view = view;
        this.#model = model;
    }

    // Fungsi utama untuk menangani proses registrasi
    // Memanggil API register, mengelola feedback ke view
    async getRegistered({ name, email, password }) {
        this.#view.showSubmitLoadingButton(); // Menampilkan tombol loading saat proses registrasi dimulai.
        try {
            // Memanggil API untuk registrasi pengguna baru.
            const response = await this.#model.getRegistered({ name, email, password });

            // Jika respons tidak OK, tampilkan pesan error ke pengguna.
            if (!response.ok) {
                console.error('getRegistered: response:', response);
                this.#view.registeredFailed(response.message);
                return;
            }

            // Jika registrasi berhasil, tampilkan pesan sukses.
            this.#view.registeredSuccessfully(response.message, response.data);
        } catch (error) {
            // Tangani error jika terjadi masalah selama proses registrasi.
            console.error('getRegistered: error:', error);
            this.#view.registeredFailed(error.message);
        } finally {
            // Sembunyikan tombol loading setelah proses selesai.
            this.#view.hideSubmitLoadingButton();
        }
    }
}
